﻿using System;
using System.Data;
using MySql.Data.MySqlClient;  // Add this for MySQL support
using System.Configuration;
using System.Web.UI.WebControls;  // Needed for Button control

namespace parkingstickerslot__g2.Pages
{
    public partial class Admin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadStickerRequests("Pending");
            }
        }

        private void LoadStickerRequests(string status)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["MySqlConnection"].ConnectionString;
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                MySqlCommand cmd = new MySqlCommand("SELECT id, user_id, vehicle_type, vehicle_brand, plate_number, gdrive_link, status FROM sticker_request WHERE status = @Status", conn);
                cmd.Parameters.AddWithValue("@Status", status);
                MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                gvStickerRequests.DataSource = dt;
                gvStickerRequests.DataBind();
            }
        }

        protected void ddlStatusFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedStatus = ddlStatusFilter.SelectedValue;
            LoadStickerRequests(selectedStatus);
        }

        protected void StickerRequestAction_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            string requestID = btn.CommandArgument;
            string action = btn.CommandName;
            string status = action == "Accept" ? "Accepted" : "Denied";

            string connectionString = ConfigurationManager.ConnectionStrings["MySqlConnection"].ConnectionString;
            using (MySqlConnection conn = new MySqlConnection(connectionString))
            {
                MySqlCommand cmd = new MySqlCommand("UPDATE sticker_request SET status = @Status WHERE id = @RequestID", conn);
                cmd.Parameters.AddWithValue("@Status", status);
                cmd.Parameters.AddWithValue("@RequestID", requestID);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }

            // Reload sticker requests to reflect the changes based on the selected filter
            LoadStickerRequests(ddlStatusFilter.SelectedValue);
        }
    }
}
