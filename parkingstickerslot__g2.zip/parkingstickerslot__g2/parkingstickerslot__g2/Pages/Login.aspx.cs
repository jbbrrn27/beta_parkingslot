﻿using System;
using MySql.Data.MySqlClient;

namespace parkingstickerslot__g2
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Optional: Code to run on page load
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string connString = System.Configuration.ConfigurationManager.ConnectionStrings["MySqlConnection"].ConnectionString;

            using (MySqlConnection conn = new MySqlConnection(connString))
            {
                try
                {
                    conn.Open();

                    // SQL query to check if the user exists and get user_id
                    string query = "SELECT user_id FROM user_account WHERE username = @username AND password = @password";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim());
                        cmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim());

                        // Execute the query and get the user_id
                        object result = cmd.ExecuteScalar();

                        // Check if login is successful
                        if (result != null)
                        {
                            // Store the user_id and username in session
                            Session["UserID"] = result.ToString();
                            Session["username"] = txtUsername.Text.Trim(); // Store the username
                            Response.Redirect("Index.aspx");
                        }

                        else
                        {
                            // Display error message
                            lblMessage.Text = "Invalid username or password.";
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Handle any errors that might occur during the database operation
                    lblMessage.Text = "Error: " + ex.Message;
                }
            }
        }
    }
}
