﻿using System;
using MySql.Data.MySqlClient;
using System.Web.UI.WebControls;

namespace parkingstickerslot__g2
{
    public partial class StickerReq_g2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["UserId"] == null)
                {
                    Response.Redirect("Login.aspx");
                }
            }
        }

        protected void carType_SelectedIndexChanged(object sender, EventArgs e)
        {
            vehicleBrand.Items.Clear();

            // Populate the vehicle brand dropdown based on the selected vehicle type
            if (carType.SelectedValue == "Car")
            {
                vehicleBrand.Items.Add(new ListItem("--Select--", ""));
                vehicleBrand.Items.Add(new ListItem("Chevrolet", "Chevrolet"));
                vehicleBrand.Items.Add(new ListItem("Toyota", "Toyota"));
                vehicleBrand.Items.Add(new ListItem("Honda", "Honda"));
                vehicleBrand.Items.Add(new ListItem("Ford", "Ford"));
                vehicleBrand.Items.Add(new ListItem("Mitsubishi", "Mitsubishi"));
                vehicleBrand.Items.Add(new ListItem("Nissan", "Nissan"));
                vehicleBrand.Items.Add(new ListItem("Hyundai", "Hyundai"));
                vehicleBrand.Items.Add(new ListItem("Suzuki", "Suzuki"));
            }
            else if (carType.SelectedValue == "Motorcycle")
            {
                vehicleBrand.Items.Add(new ListItem("--Select--", ""));
                vehicleBrand.Items.Add(new ListItem("Kawasaki", "Kawasaki"));
                vehicleBrand.Items.Add(new ListItem("Yamaha", "Yamaha"));
                vehicleBrand.Items.Add(new ListItem("Honda", "Honda"));
                vehicleBrand.Items.Add(new ListItem("Suzuki", "Suzuki"));
                vehicleBrand.Items.Add(new ListItem("Rusi", "Rusi"));
            }
        }

        protected void SubmitButton_Click(object sender, EventArgs e)
        {
            // Ensure UserId is available
            if (Session["UserId"] == null)
            {
                lblMessage.Text = "Error: User not logged in.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            int userId;
            if (!int.TryParse(Session["UserId"].ToString(), out userId))
            {
                lblMessage.Text = "Error: Invalid user ID.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            // Ensure all form fields are filled before proceeding
            if (string.IsNullOrEmpty(carType.SelectedValue) ||
                string.IsNullOrEmpty(vehicleBrand.SelectedValue) ||
                string.IsNullOrEmpty(plateNo.Text.Trim()) ||
                string.IsNullOrEmpty(gdriveLink.Text.Trim()))
            {
                lblMessage.Text = "Error: All fields are required.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }
            // Get the connection string
            string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["MySqlConnection"]?.ConnectionString;

            if (string.IsNullOrEmpty(connectionString))
            {
                lblMessage.Text = "Error: Database connection is not configured correctly.";
                lblMessage.ForeColor = System.Drawing.Color.Red;
                return;
            }

            string vehicleType = carType.SelectedValue;
            string vehicleBrandText = vehicleBrand.SelectedValue;
            string plateNumber = plateNo.Text.Trim();
            string gdriveLinkText = gdriveLink.Text.Trim();

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Insert data into the database
                    string query = "INSERT INTO sticker_request (user_id, vehicle_type, vehicle_brand, plate_number, gdrive_link) " +
                                   "VALUES (@UserId, @VehicleType, @VehicleBrand, @PlateNumber, @GDriveLink)";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@UserId", userId);
                    cmd.Parameters.AddWithValue("@VehicleType", vehicleType);
                    cmd.Parameters.AddWithValue("@VehicleBrand", vehicleBrandText);
                    cmd.Parameters.AddWithValue("@PlateNumber", plateNumber);
                    cmd.Parameters.AddWithValue("@GDriveLink", gdriveLinkText);

                    cmd.ExecuteNonQuery();
                }

                // Redirect to Index.aspx with a success status
                Response.Redirect("Index.aspx?status=success");
            }
            catch (MySqlException ex)
            {
                // Handle duplicate entry error (Error number 1062 in MySQL is for duplicate entry)
                if (ex.Number == 1062)
                {
                    lblMessage.Text = "Error: Plate number already exists.";
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                }
                else
                {
                    lblMessage.Text = "Database error: " + ex.Message;
                    lblMessage.ForeColor = System.Drawing.Color.Red;
                }
            }
            catch (Exception ex)
            {
                lblMessage.Text = "Error: " + ex.Message;
                lblMessage.ForeColor = System.Drawing.Color.Red;
            }
        }

    }
}
